class LoginMethod extends HTMLElement {
  connectedCallback() {
    this.attachShadow({ mode: 'open' });
    const name = this.getAttribute('name');
    const icon = this.getAttribute('icon');
    
    this.shadowRoot.innerHTML = `
      <style>
        .method {
          background: rgba(31, 41, 55, 0.7);
          border-radius: 0.5rem;
          padding: 0.75rem;
          display: flex;
          flex-direction: column;
          align-items: center;
          cursor: pointer;
          transition: all 0.3s ease;
          border: 1px solid rgba(217, 70, 239, 0.2);
        }
        .method:hover {
          transform: translateY(-4px);
          box-shadow: 0 4px 6px -1px rgba(217, 70, 239, 0.3);
          border-color: rgba(217, 70, 239, 0.5);
        }
        .method.selected {
          border: 2px solid #d946ef;
          background: rgba(217, 70, 239, 0.1);
        }
        .icon {
          width: 1.5rem;
          height: 1.5rem;
          margin-bottom: 0.5rem;
          color: #e5e7eb;
        }
        .name {
          font-size: 0.75rem;
          text-align: center;
          color: #e5e7eb;
        }
      </style>
      <div class="method">
        <i data-feather="${icon}" class="icon"></i>
        <span class="name">${name}</span>
      </div>
    `;
  }
}
customElements.define('login-method', LoginMethod);