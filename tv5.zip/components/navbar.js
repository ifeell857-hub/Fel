class CustomNavbar extends HTMLElement {
  connectedCallback() {
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.innerHTML = `
      <style>
        nav {
          background: rgba(17, 24, 39, 0.8);
          backdrop-filter: blur(10px);
          padding: 1rem 2rem;
          display: flex;
          justify-content: space-between;
          align-items: center;
          border-bottom: 1px solid rgba(124, 58, 237, 0.3);
        }
        .logo {
          color: white;
          font-weight: bold;
          font-size: 1.25rem;
          background: linear-gradient(135deg, #7c3aed 0%, #d946ef 100%);
          -webkit-background-clip: text;
          background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        .nav-links {
          display: flex;
          gap: 1.5rem;
          list-style: none;
          margin: 0;
          padding: 0;
        }
        a {
          color: #d1d5db;
          text-decoration: none;
          transition: color 0.2s;
          font-weight: 500;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }
        a:hover {
          color: #a78bfa;
        }
        .icon {
          width: 18px;
          height: 18px;
        }
        @media (max-width: 768px) {
          nav {
            flex-direction: column;
            gap: 1rem;
            padding: 1rem;
          }
          .nav-links {
            gap: 1rem;
          }
        }
      </style>
      <nav>
        <div class="logo">TOTOHAX V5</div>
        <ul class="nav-links">
          <li><a href="#"><i data-feather="home" class="icon"></i> Home</a></li>
          <li><a href="#"><i data-feather="user" class="icon"></i> Profile</a></li>
          <li><a href="#"><i data-feather="help-circle" class="icon"></i> FAQ</a></li>
        </ul>
      </nav>
    `;
  }
}
customElements.define('custom-navbar', CustomNavbar);