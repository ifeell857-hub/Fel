class GameCard extends HTMLElement {
  connectedCallback() {
    this.attachShadow({ mode: 'open' });
    const name = this.getAttribute('name');
    const image = this.getAttribute('image');
    
    this.shadowRoot.innerHTML = `
      <style>
        .card {
          background: rgba(31, 41, 55, 0.7);
          border-radius: 0.5rem;
          padding: 0.75rem;
          display: flex;
          flex-direction: column;
          align-items: center;
          cursor: pointer;
          transition: all 0.3s ease;
          border: 1px solid rgba(124, 58, 237, 0.2);
        }
        .card:hover {
          transform: translateY(-4px);
          box-shadow: 0 4px 6px -1px rgba(124, 58, 237, 0.3);
          border-color: rgba(124, 58, 237, 0.5);
        }
        .card.selected {
          border: 2px solid #7c3aed;
          background: rgba(124, 58, 237, 0.1);
        }
        .image {
          width: 4rem;
          height: 4rem;
          object-fit: cover;
          border-radius: 0.5rem;
          margin-bottom: 0.5rem;
        }
        .name {
          font-size: 0.75rem;
          text-align: center;
          color: #e5e7eb;
        }
      </style>
      <div class="card">
        <img src="${image}" alt="${name}" class="image">
        <span class="name">${name}</span>
      </div>
    `;
  }
}
customElements.define('game-card', GameCard);